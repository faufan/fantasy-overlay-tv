package com.fantasyoverlay.tv;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;

/** Saved settings. Stored in the app's private storage on the TV. */
final class Prefs {
    static final int[] WIDTHS = {22, 26, 30, 34};          // percent of screen width
    static final int[] OPACITIES = {70, 80, 90, 100};      // percent background opacity

    private static final String FILE = "overlay";

    private Prefs() {}

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    static String workerUrl(Context c) { return sp(c).getString("url", ""); }
    static String key(Context c) { return sp(c).getString("key", ""); }
    static int width(Context c) { return sp(c).getInt("width", 26); }
    static int opacity(Context c) { return sp(c).getInt("opacity", 90); }
    static boolean demo(Context c) { return sp(c).getBoolean("demo", false); }

    static void saveConnection(Context c, String url, String key) {
        sp(c).edit().putString("url", url.trim()).putString("key", key.trim()).apply();
    }
    static void setWidth(Context c, int v) { sp(c).edit().putInt("width", v).apply(); }
    static void setOpacity(Context c, int v) { sp(c).edit().putInt("opacity", v).apply(); }
    static void setDemo(Context c, boolean v) { sp(c).edit().putBoolean("demo", v).apply(); }

    static int next(int[] options, int current) {
        for (int i = 0; i < options.length; i++) {
            if (options[i] == current) return options[(i + 1) % options.length];
        }
        return options[0];
    }

    /** Only https Worker addresses are accepted. */
    static boolean isValidUrl(String url) {
        if (url == null) return false;
        Uri u = Uri.parse(url.trim());
        return "https".equals(u.getScheme()) && u.getHost() != null && !u.getHost().isEmpty();
    }

    static String host(Context c) {
        Uri u = Uri.parse(workerUrl(c));
        return u.getHost() == null ? "" : u.getHost();
    }

    /** The Worker's /panel page with this TV's settings. */
    static String panelUrl(Context c) {
        String base = workerUrl(c);
        while (base.endsWith("/")) base = base.substring(0, base.length() - 1);
        Uri.Builder b = Uri.parse(base).buildUpon()
                .appendPath("panel")
                .appendQueryParameter("opacity", String.valueOf(opacity(c) / 100.0))
                .appendQueryParameter("every", "20");
        String key = key(c);
        if (!key.isEmpty()) b.appendQueryParameter("key", key);
        if (demo(c)) b.appendQueryParameter("demo", "1");
        return b.build().toString();
    }
}
