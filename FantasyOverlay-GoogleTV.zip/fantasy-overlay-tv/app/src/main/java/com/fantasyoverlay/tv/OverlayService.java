package com.fantasyoverlay.tv;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.WindowManager;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * Floats the fantasy panel on the right edge of the screen, on top of whatever
 * app is playing. The panel never takes remote input, so the remote keeps
 * controlling the game underneath.
 */
public class OverlayService extends Service {
    static final String ACTION_STOP = "com.fantasyoverlay.tv.STOP";
    static final String ACTION_REFRESH = "com.fantasyoverlay.tv.REFRESH";

    private static final String CHANNEL = "overlay";
    private static volatile boolean running = false;

    private WindowManager wm;
    private WebView web;
    private WindowManager.LayoutParams lp;

    static boolean isRunning() { return running; }

    static void start(Context c) {
        c.startForegroundService(new Intent(c, OverlayService.class));
    }

    static void stop(Context c) {
        c.stopService(new Intent(c, OverlayService.class));
    }

    static void refresh(Context c) {
        if (running) {
            c.startForegroundService(new Intent(c, OverlayService.class).setAction(ACTION_REFRESH));
        }
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        goForeground();
        String action = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(action) || !Prefs.isValidUrl(Prefs.workerUrl(this))) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (web == null) {
            show();
        } else {
            applySize();
            web.loadUrl(Prefs.panelUrl(this));
        }
        running = true;
        return START_STICKY;
    }

    private void goForeground() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Fantasy overlay", NotificationManager.IMPORTANCE_MIN));
        }
        Notification n = new Notification.Builder(this, CHANNEL)
                .setContentTitle("Fantasy overlay is on")
                .setSmallIcon(android.R.drawable.ic_menu_info_details)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(1, n);
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void show() {
        wm = getSystemService(WindowManager.class);
        web = new WebView(this);
        web.setBackgroundColor(Color.TRANSPARENT);
        web.setFocusable(false);
        web.setFocusableInTouchMode(false);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);          // the panel is a live page
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setMediaPlaybackRequiresUserGesture(true);

        web.setWebViewClient(new WebViewClient() {
            // Stay on your Worker; never wander off to another site.
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                return !("https".equals(u.getScheme()) && Prefs.host(OverlayService.this).equals(u.getHost()));
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError err) {
                if (req.isForMainFrame()) {
                    view.loadDataWithBaseURL(null, errorPage("Can’t reach your Worker. Check the address and your internet connection."),
                            "text/html", "utf-8", null);
                    view.postDelayed(() -> { if (web != null) web.loadUrl(Prefs.panelUrl(OverlayService.this)); }, 30000);
                }
            }
        });

        lp = new WindowManager.LayoutParams(
                0,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.END | Gravity.TOP;
        lp.width = panelWidth();
        wm.addView(web, lp);
        web.loadUrl(Prefs.panelUrl(this));
    }

    private int panelWidth() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        return Math.round(dm.widthPixels * Prefs.width(this) / 100f);
    }

    private void applySize() {
        if (web == null || lp == null) return;
        lp.width = panelWidth();
        wm.updateViewLayout(web, lp);
    }

    private static String errorPage(String msg) {
        return "<html><body style=\"margin:0;height:100vh;display:flex;align-items:center;justify-content:center;"
                + "background:rgba(9,12,18,.9);color:#FFB57A;font:600 16px sans-serif;text-align:center;padding:24px;"
                + "box-sizing:border-box\">" + msg + "</body></html>";
    }

    @Override
    public void onDestroy() {
        running = false;
        if (web != null) {
            try { wm.removeView(web); } catch (Exception ignored) { }
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
