package com.fantasyoverlay.tv;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * The screen you see when you open the app from the Google TV home screen.
 * Turn the overlay on or off, then press Back to return to your game.
 */
public class MainActivity extends Activity {
    private EditText urlField, keyField;
    private TextView status;
    private Button toggleBtn, permBtn, widthBtn, opacityBtn, demoBtn;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(48), dp(32), dp(48), dp(32));
        col.setBackgroundColor(Color.rgb(9, 12, 18));

        TextView title = text("Fantasy Overlay", 30, true);
        col.addView(title);
        status = text("", 16, false);
        status.setTextColor(Color.rgb(154, 164, 178));
        status.setPadding(0, dp(6), 0, dp(18));
        col.addView(status);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        toggleBtn = button("Show overlay", v -> toggle());
        permBtn = button("Allow overlay", v -> requestPermission());
        widthBtn = button("", v -> { Prefs.setWidth(this, Prefs.next(Prefs.WIDTHS, Prefs.width(this))); afterChange(); });
        opacityBtn = button("", v -> { Prefs.setOpacity(this, Prefs.next(Prefs.OPACITIES, Prefs.opacity(this))); afterChange(); });
        demoBtn = button("", v -> { Prefs.setDemo(this, !Prefs.demo(this)); afterChange(); });
        row.addView(toggleBtn);
        row.addView(permBtn);
        row.addView(widthBtn);
        row.addView(opacityBtn);
        row.addView(demoBtn);
        col.addView(row);

        col.addView(label("Worker address"));
        urlField = field("https://fantasy-panel.yourname.workers.dev", InputType.TYPE_TEXT_VARIATION_URI);
        col.addView(urlField);

        col.addView(label("Access key"));
        keyField = field("The ACCESS_KEY you set in Cloudflare", InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        col.addView(keyField);

        col.addView(button("Save", v -> { if (saveFields()) { OverlayService.refresh(this); toast("Saved"); } }));

        TextView tip = text("Tip: typing is easier with the Google TV app on your phone — its keyboard types into these boxes.", 14, false);
        tip.setTextColor(Color.rgb(94, 104, 118));
        tip.setPadding(0, dp(18), 0, 0);
        col.addView(tip);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(9, 12, 18));
        scroll.addView(col);
        setContentView(scroll);

        urlField.setText(Prefs.workerUrl(this));
        keyField.setText(Prefs.key(this));
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshUi();
        toggleBtn.requestFocus();
    }

    private void toggle() {
        if (OverlayService.isRunning()) {
            OverlayService.stop(this);
            refreshUi();
            return;
        }
        if (!saveFields()) return;
        if (!Settings.canDrawOverlays(this)) { requestPermission(); return; }
        OverlayService.start(this);
        toast("Overlay on. Press Back to return to your game.");
        toggleBtn.postDelayed(this::refreshUi, 300);
    }

    private boolean saveFields() {
        String url = urlField.getText().toString().trim();
        String key = keyField.getText().toString().trim();
        if (!Prefs.isValidUrl(url)) {
            urlField.setError("Use your Worker's https:// address");
            urlField.requestFocus();
            return false;
        }
        Prefs.saveConnection(this, url, key);
        return true;
    }

    private void requestPermission() {
        Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
        try {
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            status.setText("This TV hides the “display over other apps” setting. From a computer, run:\n"
                    + "adb shell appops set " + getPackageName() + " SYSTEM_ALERT_WINDOW allow\n"
                    + "(see the README for the full steps), then come back here.");
        }
    }

    private void afterChange() {
        OverlayService.refresh(this);
        refreshUi();
    }

    private void refreshUi() {
        boolean allowed = Settings.canDrawOverlays(this);
        boolean on = OverlayService.isRunning();
        toggleBtn.setText(on ? "Hide overlay" : "Show overlay");
        permBtn.setVisibility(allowed ? View.GONE : View.VISIBLE);
        widthBtn.setText("Width " + Prefs.width(this) + "%");
        opacityBtn.setText("Opacity " + Prefs.opacity(this) + "%");
        demoBtn.setText(Prefs.demo(this) ? "Demo data: on" : "Demo data: off");
        if (!allowed) {
            status.setText("One-time step: allow this app to display over other apps.");
        } else if (on) {
            status.setText("Overlay is on. Press Back to return to your game.");
        } else {
            status.setText("Overlay is off.");
        }
    }

    // --- Small UI helpers ---------------------------------------------------

    private int dp(int v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()));
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(Color.rgb(243, 245, 248));
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView label(String s) {
        TextView t = text(s, 15, true);
        t.setPadding(0, dp(20), 0, dp(4));
        return t;
    }

    private EditText field(String hint, int variation) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT | variation);
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(Color.rgb(94, 104, 118));
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        return e;
    }

    private Button button(String s, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMarginEnd(dp(10));
        p.gravity = Gravity.START;
        b.setLayoutParams(p);
        return b;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }
}
